import React, { createContext, useState } from 'react';

export const QuizContext = createContext();

export const QuizProvider = ({ children }) => {
  const [score, setScore] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});

  // Function to reset the quiz data
  const resetQuiz = () => {
    setScore(0); // Reset score to 0
    setSelectedAnswers({}); // Reset selected answers
  };

  return (
    <QuizContext.Provider value={{ score, setScore, selectedAnswers, setSelectedAnswers, resetQuiz }}>
      {children}
    </QuizContext.Provider>
  );
};
