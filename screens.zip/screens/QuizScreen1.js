import React, { useContext, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { QuizContext } from '../Context/QuizContext';

const QuizScreen1 = ({ navigation }) => {
  const { score, setScore, selectedAnswers, setSelectedAnswers, resetQuiz } = useContext(QuizContext);

  useEffect(() => {
    // Clear selected answers when screen is loaded
    setSelectedAnswers({});
  }, [setSelectedAnswers]);

  const questions = [
    { id: '1', question: 'What is 2+2?', options: ['3', '4', '5'], correct: '4' },
    { id: '2', question: 'What is the capital of France?', options: ['Berlin', 'Madrid', 'Paris'], correct: 'Paris' },
    { id: '3', question: 'What is the color of the sky?', options: ['Green', 'Blue', 'Yellow'], correct: 'Blue' },
    { id: '4', question: 'What is 3+5?', options: ['8', '7', '9'], correct: '8' },
    { id: '5', question: 'What is the largest planet?', options: ['Earth', 'Jupiter', 'Mars'], correct: 'Jupiter' },
    { id: '6', question: 'What is the boiling point of water?', options: ['90°C', '100°C', '110°C'], correct: '100°C' }
  ];

  const handleAnswer = (questionId, answer) => {
    const updatedAnswers = { ...selectedAnswers, [questionId]: answer };
    setSelectedAnswers(updatedAnswers);

    const question = questions.find(q => q.id === questionId);
    if (question.correct === answer && selectedAnswers[questionId] !== answer) {
      setScore(score + 1);
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={questions}
        renderItem={({ item, index }) => (
          <View style={styles.questionBlock}>
            <Text style={styles.questionText}>{index + 1}. {item.question}</Text>
            {item.options.map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.option,
                  selectedAnswers[item.id] === option && styles.selectedOption,
                ]}
                onPress={() => handleAnswer(item.id, option)}
              >
                <View style={styles.radioCircle}>
                  {selectedAnswers[item.id] === option && <View style={styles.selectedRb} />}
                </View>
                <Text style={styles.optionText}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        keyExtractor={(item) => item.id}
      />

      <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('Quiz 2')}>
        <Text style={styles.nextButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d0e8f2',
    padding: 15,
  },
  questionBlock: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  questionText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  selectedOption: {
    backgroundColor: '#cce5ff',
  },
  radioCircle: {
    height: 18,
    width: 18,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  selectedRb: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#007AFF',
  },
  optionText: {
    fontSize: 16,
    color: '#333',
  },
  nextButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    marginVertical: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default QuizScreen1;
