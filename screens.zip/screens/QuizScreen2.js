import React, { useContext, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { QuizContext } from '../Context/QuizContext';

const QuizScreen2 = ({ navigation }) => {
  const { score, setScore, selectedAnswers, setSelectedAnswers, resetQuiz } = useContext(QuizContext);

  useEffect(() => {
    // Clear selected answers when screen is loaded
    setSelectedAnswers({});
  }, [setSelectedAnswers]);

  const questions = [
    { id: '7', question: 'What is 5+5?', options: ['10', '9', '11'], correct: '10' },
    { id: '8', question: 'Which planet is known as the Red Planet?', options: ['Venus', 'Mars', 'Saturn'], correct: 'Mars' },
    { id: '9', question: 'What is the capital of Japan?', options: ['Beijing', 'Seoul', 'Tokyo'], correct: 'Tokyo' },
    { id: '10', question: 'What is the tallest mountain?', options: ['K2', 'Everest', 'Kangchenjunga'], correct: 'Everest' },
    { id: '11', question: 'What is the freezing point of water?', options: ['32°F', '0°C', '50°F'], correct: '0°C' },
    { id: '12', question: 'Who painted the Mona Lisa?', options: ['Van Gogh', 'Da Vinci', 'Picasso'], correct: 'Da Vinci' }
  ];

  const handleAnswer = (questionId, answer) => {
    const updatedAnswers = { ...selectedAnswers, [questionId]: answer };
    setSelectedAnswers(updatedAnswers);

    const question = questions.find(q => q.id === questionId);
    if (question.correct === answer && selectedAnswers[questionId] !== answer) {
      setScore(score + 1);
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={questions}
        renderItem={({ item, index }) => (
          <View style={styles.questionBlock}>
            <Text style={styles.questionText}>{index + 7}. {item.question}</Text>
            {item.options.map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.option,
                  selectedAnswers[item.id] === option && styles.selectedOption,
                ]}
                onPress={() => handleAnswer(item.id, option)}
              >
                <View style={styles.radioCircle}>
                  {selectedAnswers[item.id] === option && <View style={styles.selectedRb} />}
                </View>
                <Text style={styles.optionText}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        keyExtractor={(item) => item.id}
      />

      <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('Score')}>
        <Text style={styles.nextButtonText}>See Score</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d0e8f2',
    padding: 15,
  },
  questionBlock: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  questionText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  selectedOption: {
    backgroundColor: '#cce5ff',
  },
  radioCircle: {
    height: 18,
    width: 18,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  selectedRb: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#007AFF',
  },
  optionText: {
    fontSize: 16,
    color: '#333',
  },
  nextButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    marginVertical: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default QuizScreen2;
