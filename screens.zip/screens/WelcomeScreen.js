import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

const WelcomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/logo.png')}  // Adjust path if needed
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={styles.title}>Welcome to the Trivia Quiz!</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Start Quiz"
          color="#007AFF"
          onPress={() => navigation.navigate('Quiz 1')}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d0e8f2',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 30,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#333',
  },
  buttonContainer: {
    width: 200,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
  },
});

export default WelcomeScreen;
